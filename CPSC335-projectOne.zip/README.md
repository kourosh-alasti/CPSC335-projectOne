# CPSC335
## Project 1
### Our Info
#### Kevin Nguyen and Kourosh Alasti
#
Kevin Nguyen: oggunderscore@csu.fullerton.edu 
<br/>
Kourosh Alasti: kalasti@csu.fullerton.edu

## How to run
```python3 project1_starter.py```
